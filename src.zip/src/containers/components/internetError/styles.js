import { StyleSheet } from "react-native";

export default StyleSheet.create({
  view_disconnect: {
    flex: 1,
    flexDirection: "column",
    justifyContent: "center",
    alignItems: "center"
  },
  txt_disconnect: {
    textAlign: "center"
  }
});
