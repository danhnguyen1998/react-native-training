export const API_URL = 'http://dev2.pre.ptminder.com';
export const USER_KEY = 'token';
export const USER_LOGIN = 'userLogin';
