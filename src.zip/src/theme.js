
export default {
  Text: {
    style: {
      letterSpacing: 0
    }
  }
};
