import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-elements';

export default class ServiceComponent extends React.Component {
    render() {
        return (
            <View>
                <Text style={{ marginTop: 100 }}>Service Screen</Text>
            </View>
        );
    }
}
