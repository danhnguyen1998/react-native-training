import { createActions } from 'redux-actions';

const actions = createActions({
    LOGIN_ACTION: null
});

export const { logInAction } = actions;