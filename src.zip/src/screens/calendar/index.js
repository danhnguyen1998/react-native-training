import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-elements';

export default class CalendarComponent extends React.Component {
    render() {
        return (
            <View>
                <Text style={{ marginTop: 100 }}>Calendar Screen</Text>

            </View>
        );
    }
}
