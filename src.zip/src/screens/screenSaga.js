import loginSaga from './login/redux/operations';
export default {
  ...loginSaga,
};
